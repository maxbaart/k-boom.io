// Get the canvas and context
var canvas;
var ctx;

// Game variables
const player = { x: 400, y: 300, size: 70, speed: 5 };
const bullets = [];
let mouseX = player.x; // Initialize mouseX
let mouseY = player.y; // Initialize mouseY

function createBullet(x, y, direction) {
    return {
        x: x,
        y: y,
        size: 12,
        speed: 10,
        direction: direction
    };
}

function updateBullets() {
    for (let i = bullets.length - 1; i >= 0; i--) {
        const bullet = bullets[i];
        bullet.x += bullet.direction.x * bullet.speed;
        bullet.y += bullet.direction.y * bullet.speed;

        // Remove bullets that go off-screen
        if (bullet.x < 0 || bullet.x > canvas.width || bullet.y < 0 || bullet.y > canvas.height) {
            bullets.splice(i, 1);
        }
    }
}

function drawBullets() {
    ctx.fillStyle = 'red';
    for (const bullet of bullets) {
        ctx.fillRect(bullet.x, bullet.y, bullet.size, bullet.size);
    }
}

document.addEventListener('keydown', (event) => {
    if (event.key === ' ') { // Space key to shoot
        // Calculate direction vector for bullet
        const dx = mouseX - (player.x + player.size / 2);
        const dy = mouseY - (player.y + player.size / 2);
        const magnitude = Math.sqrt(dx * dx + dy * dy);
        const direction = { x: dx / magnitude, y: dy / magnitude };

        // Create and store the bullet
        const bullet = createBullet(player.x + player.size / 2, player.y + player.size / 2, direction);
        bullets.push(bullet);
    }
});

window.addEventListener("load", () => {
    canvas = document.getElementById('gameCanvas');
    ctx = canvas.getContext('2d');

    canvas.addEventListener('mousemove', (event) => {
        // Get the canvas's bounding box
        const rect = canvas.getBoundingClientRect();

        // Update mouse position relative to the canvas
        mouseX = event.clientX - rect.left;
        mouseY = event.clientY - rect.top;
    });

    background = new Image();
    background.src = '../assets/tile1.webp'; // Replace with the correct path to your image

    background.onload = () => {
        gameLoop();
    };
});

// Game loop
function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

    // Update and draw bullets
    updateBullets();
    drawBullets();

    // Update player position toward the mouse
    const dx = mouseX - (player.x + player.size / 2);
    const dy = mouseY - (player.y + player.size / 2);
    const distance = Math.sqrt(dx * dx + dy * dy);

    // Only move the player toward the mouse if it's far enough to avoid jittering
    if (distance > 1) {
        player.x += dx * 0.005; // Adjust the speed of movement (0.1 controls how fast the player moves towards the mouse)
        player.y += dy * 0.005;
    }

    // Draw the player
    ctx.fillStyle = 'white';
    ctx.fillRect(player.x, player.y, player.size, player.size);

    // Request the next frame
    requestAnimationFrame(gameLoop);
}
